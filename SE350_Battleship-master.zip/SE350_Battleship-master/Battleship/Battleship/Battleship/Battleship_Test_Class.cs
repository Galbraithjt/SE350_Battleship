﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;

namespace Battleship
{
	[TestFixture]
	public class Battleship_Test_Class
	{
		[Test]
		public void StartUp()
		{

		}
	}
}
