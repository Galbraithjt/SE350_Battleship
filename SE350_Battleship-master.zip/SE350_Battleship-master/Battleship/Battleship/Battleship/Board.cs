﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    class Board
    {
		public Player playerOne;
		public Player playerTwo;
		public System.Windows.Point fireLocation;
		public enum fireState
		{
			MISS = 0,
			HIT = 1,
			INVALID = 2
		}
		public Board()
		{
			playerOne = new Player();
			playerTwo = new Player();
		}
		public void SelectSquare(System.Windows.Point selectedSquare, Grid grid)
		{
			fireLocation.X = Math.Floor(Math.Abs((selectedSquare.X - grid.gridWidthStart) + 7) / 20);
			fireLocation.Y = Math.Floor(Math.Abs((selectedSquare.Y - grid.gridHeightStart) + 5) / 20);
		}
		public void PlaceShips(Grid grid)
		{
			grid.playerShips[0] = new Ship(0, 0, 2, "PB");
			grid.playerShips[1] = new Ship(0, 0, 3, "SSBN");
			grid.playerShips[2] = new Ship(0, 0, 3, "DDG");
			grid.playerShips[3] = new Ship(0, 0, 4, "BB");
			grid.playerShips[4] = new Ship(0, 0, 5, "CVN");
			for (int x = 0; x < grid.playerShips.Length; x++)
			{
				grid.PlaceShips(grid, grid.playerShips[x]);
			}
		}
		public int FireShot(Grid targetGrid)
		{
			//Check to see if a hit or miss occurs on firing location. Return true if the selection has not
			//been previously fired upon; false if it has.
			if (targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] == (int)fireState.MISS)
			{
				targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] = 3;
				return (int)fireState.MISS;
			}
			else
			if (targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] == (int)fireState.HIT)
			{
				targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] = 4;
				targetGrid.IsHit(fireLocation);
				return (int)fireState.HIT;
			}
			else
			{
				return (int)fireState.INVALID;
			}
		}
		public bool PerformTurn()
		{
			bool hitOrMiss = false;
			if (playerOne.active == true)
			{
				hitOrMiss = PerformPlayerTurn();
			}
			else
			{
				hitOrMiss = PerformCPUTurn();
			}
			for (int x = 0; x < playerOne.playerGrid.playerShips.Length; x++)
			{
				if (playerOne.playerGrid.playerShips[x].health == 0 &&
						playerOne.playerGrid.playerShips[x].status == true)
				{
					System.Windows.MessageBox.Show("Enemy has sunk " + playerOne.playerGrid.playerShips[x].name
																						+ " Commander! ");
					playerOne.playerGrid.playerShips[x].status = false;
				}
			}
			for (int x = 0; x < playerTwo.playerGrid.playerShips.Length; x++)
			{
				if (playerTwo.playerGrid.playerShips[x].health == 0 &&
								playerTwo.playerGrid.playerShips[x].status == true)
				{
					System.Windows.MessageBox.Show("Enemy " + playerTwo.playerGrid.playerShips[x].name
																					+ " Sunk Commander! ");
					playerTwo.playerGrid.playerShips[x].status = false;
				}
			}
			return hitOrMiss;
		}
		public bool PerformPlayerTurn()
		{
			bool hitOrMiss = false;
			int firingStatus = FireShot(playerTwo.playerGrid);
			if (firingStatus != (int)fireState.INVALID)
			{
				if (firingStatus == (int)fireState.HIT)
				{
					hitOrMiss = true;
					playerOne.playerGrid.hits++;
				}
				else
				{
					hitOrMiss = false;
					playerOne.playerGrid.misses++;
				}
				playerTwo.active = true;
				playerOne.active = false;
			}
			else
			{
				throw new Exception("This square has been fired at commander. Please choose another.");
			}
			return hitOrMiss;
		}
		public bool PerformCPUTurn()
		{
			bool hitOrMiss = false;
			int firingStatus = 0;
			do
			{
				Random rand = new Random();
				fireLocation.X = rand.Next(1, 10);
				fireLocation.Y = rand.Next(1, 10);
				firingStatus = FireShot(playerOne.playerGrid);
				if (firingStatus != (int)fireState.INVALID)
				{
					if (firingStatus == (int)fireState.HIT)
					{
						hitOrMiss = true;
						playerTwo.playerGrid.hits++;
					}
					else
				   if (firingStatus == (int)fireState.MISS)
					{
						hitOrMiss = false;
						playerTwo.playerGrid.misses++;
					}
				}
			} while (firingStatus == (int)fireState.INVALID);
			playerOne.active = true;
			playerTwo.active = false;
			return hitOrMiss;
		}
		public bool IsGameOver()
		{
			bool gameOver = false;
			if (playerOne.playerGrid.hits == 17 || playerTwo.playerGrid.hits == 17)
			{
				if (playerOne.playerGrid.hits == 17)
				{
					System.Windows.MessageBox.Show("You've defeated the enemy!");
					gameOver = true;
				}
				else
				{
					System.Windows.MessageBox.Show("You've been defeated :( ");
					gameOver = true;
				}
			}
			return gameOver;
		}
	}
}
