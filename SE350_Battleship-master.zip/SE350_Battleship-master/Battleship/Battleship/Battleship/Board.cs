﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    class Board
    {
		public Player playerOne;
		public Player playerTwo;
		public System.Windows.Point fireLocation;
		public enum fireState
		{
			MISS = 0,
			HIT = 1,
			INVALID = 2
		}
		public Board()
		{
			playerOne = new Player();
			playerTwo = new Player();
		}
		public void startGame()
		{
			playerTwo.CPU = true;
		}
		public void selectSquare(System.Windows.Point selectedSquare, Grid grid)
		{
			fireLocation.X = Math.Floor(Math.Abs((selectedSquare.X - grid.gridWidthStart) + 7) / 20);
			fireLocation.Y = Math.Floor(Math.Abs((selectedSquare.Y - grid.gridHeightStart) + 5) / 20);
		}
		public void placeShips(Grid grid)
		{
			grid.playerShips[0] = new Ship(0, 0, 2, "Patrol");
			grid.playerShips[1] = new Ship(0, 0, 3, "Submarine");
			grid.playerShips[2] = new Ship(0, 0, 3, "Cruiser");
			grid.playerShips[3] = new Ship(0, 0, 4, "Battleship");
			grid.playerShips[4] = new Ship(0, 0, 5, "Carrier");
			for (int x = 0; x < grid.playerShips.Length; x++)
			{
				grid.placeShips(grid, grid.playerShips[x]);
			}
		}
		public int fireShot(Grid targetGrid)
		{
			//Check to see if a hit or miss occurs on firing location. Return true if the selection has not
			//been previously fired upon; false if it has.
			if (targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] == (int)fireState.MISS)
			{
				targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] = 3;
				return (int)fireState.MISS;
			}
			else
			if (targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] == (int)fireState.HIT)
			{
				targetGrid.GridLocation[Convert.ToInt32(fireLocation.X), Convert.ToInt32(fireLocation.Y)] = 4;
				targetGrid.isHit(fireLocation);
				return (int)fireState.HIT;
			}
			else
			{
				return (int)fireState.INVALID;
			}
		}
		public bool performTurn()
		{
			bool hitOrMiss = false;
			if (playerOne.active == true)
			{
				hitOrMiss = performPlayerTurn();
			}
			else
			{
				hitOrMiss = performCPUTurn();
			}
			for (int x = 0; x < playerOne.playerGrid.playerShips.Length; x++)
			{
				if (playerOne.playerGrid.playerShips[x].health == 0 &&
						playerOne.playerGrid.playerShips[x].status == true)
				{
					System.Windows.MessageBox.Show("Enemy has sunk " + playerOne.playerGrid.playerShips[x].name
																						+ " Commander! ");
					playerOne.playerGrid.playerShips[x].status = false;
				}
			}
			for (int x = 0; x < playerTwo.playerGrid.playerShips.Length; x++)
			{
				if (playerTwo.playerGrid.playerShips[x].health == 0 &&
								playerTwo.playerGrid.playerShips[x].status == true)
				{
					System.Windows.MessageBox.Show("Enemy " + playerTwo.playerGrid.playerShips[x].name
																					+ " Sunk Commander! ");
					playerTwo.playerGrid.playerShips[x].status = false;
				}
			}
			return hitOrMiss;
		}
		public bool performPlayerTurn()
		{
			bool hitOrMiss = false;
			int firingStatus = fireShot(playerTwo.playerGrid);
			if (firingStatus != (int)fireState.INVALID)
			{
				if (firingStatus == (int)fireState.HIT)
				{
					hitOrMiss = true;
					playerOne.playerGrid.hits++;
				}
				else
				{
					hitOrMiss = false;
					playerOne.playerGrid.misses++;
				}
				playerTwo.active = true;
				playerOne.active = false;
			}
			else
			{
				throw new Exception("This square has been fired at commander.Please choose another");
			}
			return hitOrMiss;
		}
		public bool performCPUTurn()
		{
			bool hitOrMiss = false;
			int firingStatus = 0;
			do
			{
				Random rand = new Random();
				fireLocation.X = rand.Next(1, 10);
				fireLocation.Y = rand.Next(1, 10);
				firingStatus = fireShot(playerOne.playerGrid);
				if (firingStatus != (int)fireState.INVALID)
				{
					if (firingStatus == (int)fireState.HIT)
					{
						hitOrMiss = true;
						playerTwo.playerGrid.hits++;
					}
					else
				   if (firingStatus == (int)fireState.MISS)
					{
						hitOrMiss = false;
						playerTwo.playerGrid.misses++;
					}
				}
			} while (firingStatus == (int)fireState.INVALID);
			playerOne.active = true;
			playerTwo.active = false;
			return hitOrMiss;
		}
		public bool isGameOver()
		{
			bool gameOver = false;
			if (playerOne.playerGrid.hits == 17 || playerTwo.playerGrid.hits == 17)
			{
				if (playerOne.playerGrid.hits == 17)
				{
					System.Windows.MessageBox.Show("You've defeated the enemy!");
				}
				else
				{
					System.Windows.MessageBox.Show("You've been defeated :( ");
				}
			}
			return gameOver;
		}
	}
}
