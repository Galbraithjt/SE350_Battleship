﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Battleship
{
    class Grid
    {
        public Ship[] playerShips;
        public int[,] GridLocation;
        public int shipsSunk;
        public int gridWidthStart;
        public int gridHeightStart;
        public int hits;
        public int misses;
        public Grid()
        {
            playerShips = new Ship[5];
            shipsSunk = 0;
            gridWidthStart = 329;
            gridHeightStart = 88;
            GridLocation = new int[10, 10];
            hits = 0;
            misses = 0;
            ClearGrid();
        }
        public void PlaceShips(Grid grid, Ship ship)
        {
            bool notPlace = false;
            do
            {
                Random ranCol = new Random();
                Random ranRow = new Random();
                if (ranCol.Next(0, 2) == 1)
                {
                    ship.direction = false;
                }
                else
                {
                    ship.direction = true;
                }

                if (ship.direction == true)
                {
                    int compare = 0;
                    int row = ranRow.Next(0, 10 - (ship.length - 1));
                    int col = ranCol.Next(0, 10);
                    while (compare < ship.length)
                    {
                        if (grid.GridLocation[(row + compare), col] == 0)
                        {
                            compare++;
                            if (compare == ship.length)
                            {
                                notPlace = true;
                                for (int x = 0; x < ship.length; x++)
                                {
                                    grid.GridLocation[(row + x), col] = 1;
                                    ship.startPoint.X = row;
                                    ship.startPoint.Y = col;
                                }
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }
                else
                {
                    int compare = 0;
                    int row = ranRow.Next(0, 10);
                    int col = ranCol.Next(0, 10 - (ship.length - 1));
                    while (compare < ship.length)
                    {
                        if (grid.GridLocation[row, (col + compare)] == 0)
                        {
                            compare++;
                            if (compare == ship.length)
                            {
                                notPlace = true;
                                for (int x = 0; x < ship.length; x++)
                                {
                                    grid.GridLocation[row, (col + x)] = 1;
                                    ship.startPoint.X = row;
                                    ship.startPoint.Y = col;
                                }
                            }
                        }
                        else
                        {
                            break;
                        }
                    }
                }






            } while (notPlace == false);

        }
        public void ClearGrid()
        {
            for (int x = 0; x < 10; x++)
            {
                for (int y = 0; y < 10; y++)
                {
                    GridLocation[x, y] = 0;
                }
            }
        }
        public void IsHit(System.Windows.Point firedLocation)
        {
            bool hitFound = false;
            for (int x = 0; x < playerShips.Length; x++)
            {
                if (hitFound == true)
                {
                    break;
                }
                for (int y = 0; y < playerShips[x].length; y++)
                {
                    if (playerShips[x].direction == true)
                    {
                        if (playerShips[x].startPoint.X + y == firedLocation.X &&
                            playerShips[x].startPoint.Y == firedLocation.Y)
                        {
                            playerShips[x].health--;
                            hitFound = true;
                            if (hitFound == true)
                            {
                                break;
                            }
                        }
                    }
                    else
                    {
                        if (playerShips[x].startPoint.Y + y == firedLocation.Y &&
                            playerShips[x].startPoint.X == firedLocation.X)
                        {
                            playerShips[x].health--;
                            hitFound = true;
                            if (hitFound == true)
                            {
                                break;
                            }
                        }
                    }
                }
            }
        }
        public void ReportShipHealth(Ship ship, bool isPlayerActive)
        {
            if (isPlayerActive == true)
            {
                if (ship.health == 0 && ship.status == true)
                {
                    ship.status = false;
                    System.Windows.MessageBox.Show("Enemy " + ship.name + " Sunk Commander!");
                }
            }
            else
            {
                if (ship.health == 0 && ship.status == true)
                {
                    ship.status = false;
                    System.Windows.MessageBox.Show("Enemy has sunk" + ship.name + " Commander!");
                }
            }
        }
    }
}